# Cognitive Wi-Fi PPO — Pipeline v2 (Yêu cầu 1: một AP)

**Trạng thái:** OFFLINE / SHADOW ONLY — digital twin **chưa hiệu chuẩn** bằng số liệu thật. **Không nạp `best_model_v2_UNCALIBRATED.zip` để tự động điều khiển router**.

## Điểm khác so với notebook cũ

1. **Đổi từ policy 8D/7D sang 12D/3D có versioned schema.** 8 đặc trưng cũ vẫn giữ nguyên, thêm 3 chỉ số cấu hình đang áp dụng và 1 chỉ số thời gian giữ cấu hình. 3 hành động được chủ dự án xác nhận có thể điều khiển AX3000T: `channel`, `bandwidth`, `tx_power`. Bốn chiều MCS, Beacon, OBSS_PD, Beamforming đang **chưa kiểm chứng**; không giả định chúng có hiệu lực và không tối ưu chúng trong checkpoint này.
2. `step()` tạo **hành động ảnh hưởng trạng thái tương lai**: công suất ảnh hưởng ước lượng tín hiệu downstream, channel/width ảnh hưởng nhiễu, năng lực phục vụ, queue, p99 mô phỏng, packet loss. Dữ liệu mô phỏng **không** phải mô phỏng đầy đủ của chuẩn IEEE 802.11 hoặc bằng chứng vật lý thực.
3. **Channel bonding 5 GHz:** primary 36/40/44 tại HE80 chiếm cùng khối 36–48, không được hiểu là ba kênh trực giao.
4. `reset(seed=...)` tái lập được. State observation chuẩn hóa `[0,1]`; quy trình suy luận phải dùng đúng encoder của v2.
5. Reward được tính từ goodput, **proxy** mức đáp ứng nhu cầu, synthetic delay tail, synthetic loss, và switching cost. Đây **không** phải hàm U(X) báo cáo nghiên cứu; synthetic p99 chỉ là phân vị của 64 mẫu độ trễ mô phỏng, **không** là số đo thực.
6. Chạy nhiều seed và đánh giá bằng tập validation chọn checkpoint, test OOD chưa dùng để chọn policy. Baseline `fixed`, `heuristic` được so sánh trên cùng seed (mô phỏng), xuất CSV + CI bootstrap theo episode.
7. Không nạp trace Kaggle không đúng loại dữ liệu; không có fallback âm thầm khi thiếu dữ liệu thật; chế độ hiện tại là **synthetic**, luôn ghi rõ.
8. Không làm việc với router qua SSH. Script `shadow_inference_v2.py` chỉ hiển thị hành động dự đoán và cảnh báo nguồn telemetry.

## Chạy trên Colab

Mở `training_digital_twin_v2_SINGLE_AP.ipynb` và chạy các cell theo thứ tự. Notebook tự ghi các script cần thiết vào thư mục hiện hành (nhờ `%%writefile`). Trong cell huấn luyện, đổi `TRAIN_NOW = False` thành `True` sau khi đã chạy unit tests.

## Chạy ở máy Linux/WSL2

```bash
python -m pip install -r requirements_v2.txt
python -m unittest test_core_v2 -v
python train_evaluate_v2.py --timesteps 360000 --seeds 11 22 33 --out runs/singleap_v2
```

Bản chạy nhanh ban đầu: `--timesteps 40000 --seeds 11` chỉ để xác nhận pipeline chạy, **không** sử dụng kết quả này làm minh chứng khoa học.

Các file output sau khi train thành công sẽ gồm:
- `runs/singleap_v2/best_model_v2_UNCALIBRATED.zip`
- `runs/singleap_v2/model_manifest_v2.json`
- `runs/singleap_v2/report_v2.json`
- `runs/singleap_v2/validation_episodes.csv`
- `runs/singleap_v2/heldout_ood_episodes.csv`
- `runs/singleap_v2/seed_*/selection/best_model.zip` và `seed_*/validation/evaluations.npz`

**Checkpoint cũ `best_model (2).zip`:** metadata chỉ ra **8D observation + 7D action**, `num_timesteps=360000`. Nó **không tương thích** với v2 (12D observation, 3D action). Không thay thế file cũ bằng v2 hoặc dùng file cũ trong script v2.

## Ánh xạ shadow

Khi có telemetry một AP đã được xác minh, dùng script:

```bash
python shadow_inference_v2.py \
  --snapshot one_ap.json \
  --checkpoint runs/singleap_v2/best_model_v2_UNCALIBRATED.zip \
  --channel-idx 0 --bw-idx 2 --tx-idx 3 --dwell-cycles 8
```

Các giá trị `--channel-idx`, `--bw-idx`, `--tx-idx` phải đọc lại từ **cấu hình AP đang áp dụng thực tế**. Không tự đoán giá trị. Dữ liệu `ofdma_ratio` trong bản OpenWrt hiện tại là **proxy** từ bitrate lines/HE adoption, chưa phải tỷ lệ OFDMA thực được đo; missing/placeholder provenance được cảnh báo chứ không che giấu.

## Điều cần đo trước khi có thể dùng trên HIL

- Bản ghi nhiều phiên testbed: tải từng luồng, throughput, P50/P95/P99, retry rate và packet loss thực, một số ít kiểm tra kênh/băng thông/công suất được áp dụng và đo lại.
- Cách xác minh `noise_floor` được đọc đúng từ survey cho kênh `[in use]`, timestamp và độ tin cậy của giá trị sau khi chuyển kênh.
- Ước lượng sai số digital twin (chênh giữa dự báo và số đo), so với baseline fixed/rule-based và MAC-only ablation.
- Dwell time, downtime và khả năng rollback thực sự của từng hành động.
- Phân tầng theo môi trường và các trường hợp out-of-distribution có chuyển về safe policy.
- Kiểm thử chính thức với phiên bản firmware `mt76`, và đầy đủ giấy phép/vùng quản lý phổ tần.

## Cảnh báo về code actuator hiện tại (ngoài phạm vi thay đổi)

- `_exec_ssh_command` trong `wifi_actuators.py` luôn `return True` sau khi đọc exit status, kể cả khi lệnh lỗi; nhiều lệnh shell dùng `|| true`, che lỗi cấu hình.
- `apply_ai_profile_atomic()` không có rollback transaction được kiểm chứng; `wifi reload` có thể làm gián đoạn thiết bị.
- `deploy_hil_agent.py` có thể ghi nhận `previous_actions` dù việc áp dụng từng tham số chưa được đọc lại từ router.
- Một số thay đổi như `he_su_beamformer`, OBSS-PD, MCS và Beacon chưa được người dùng xác minh tác dụng thực tế.
- Tên cờ Radiotap `L-SIG` (bit 27) **không** đồng nghĩa chắc chắn với bộ thu đã phát hiện `RL-SIG`; và HE-MU frame count **không** đồng nhất với tỷ lệ OFDMA thực.

## Chất lượng kiểm thử ở môi trường tạo file

Các unit tests NumPy (6 tests) đã chạy thành công. **Chưa chạy end-to-end PPO training bằng SB3** trong môi trường tạo file vì không cài được `gymnasium` / `stable-baselines3` (mạng bị giới hạn). Mã được biên dịch cú pháp và tạo notebook có thể chạy trên Colab; cần chạy notebook ở môi trường đã cài dependencies để hoàn tất kiểm chứng runtime, training và benchmark.
