"""Read SB3 archive metadata without unpickling or executing model weights."""
import sys,zipfile,json
from pathlib import Path

def info(path):
    with zipfile.ZipFile(path,'r') as z:
        d=json.loads(z.read('data'))
    return {
      'num_timesteps':d.get('num_timesteps'),
      'observation_shape':d.get('observation_space',{}).get('_shape'),
      'action_nvec':d.get('action_space',{}).get('nvec'),
      'policy_kwargs':d.get('policy_kwargs'),
      'note':'Metadata inspection only; not model inference or performance validation'
    }
if __name__=='__main__':
    print(json.dumps(info(Path(sys.argv[1])),indent=2,ensure_ascii=False))
