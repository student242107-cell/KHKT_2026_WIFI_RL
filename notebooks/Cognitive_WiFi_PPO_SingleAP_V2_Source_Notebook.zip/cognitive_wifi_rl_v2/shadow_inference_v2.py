"""Inference only. NO network requests, NO SSH, NO router changes."""
import argparse,json
from pathlib import Path
import numpy as np
from wifi_rl_core_v2 import (validate_telemetry_snapshot,encode_shadow_observation,
                            safe_legacy7_from3)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--snapshot',required=True,type=Path)
    p.add_argument('--checkpoint',required=True,type=Path)
    p.add_argument('--channel-idx',type=int,default=None)
    p.add_argument('--bw-idx',type=int,default=None)
    p.add_argument('--tx-idx',type=int,default=None)
    p.add_argument('--dwell-cycles',type=int,default=0)
    args=p.parse_args()
    from stable_baselines3 import PPO
    from train_evaluate_v2 import assert_checkpoint_schema
    if None in (args.channel_idx,args.bw_idx,args.tx_idx):
        raise ValueError('You MUST provide read-back applied config indexes; never guess current router config')
    snapshot=json.loads(args.snapshot.read_text('utf-8'))
    # If file holds multiple BSSIDs, select one explicitly upstream, never mix APs.
    if not ('avg_rssi' in snapshot):
        raise ValueError('Snapshot must describe exactly ONE AP with raw 8-D fields')
    check=validate_telemetry_snapshot(snapshot)
    obs=encode_shadow_observation(check['observation8'],
                np.array([args.channel_idx,args.bw_idx,args.tx_idx]),args.dwell_cycles)
    model=PPO.load(str(args.checkpoint),device='cpu'); assert_checkpoint_schema(model)
    choice,_=model.predict(obs,deterministic=True)
    print(json.dumps({
        'mode':'SHADOW_ONLY_NOT_FOR_ROUTER_EXECUTION',
        'proposed_action_3d_indices':list(map(int,choice)),
        'legacy_7d_mapping_for_visualization_only':list(map(int,safe_legacy7_from3(choice))),
        'alerts':check['alerts']+['No action applied','No live QoE claims','Uncalibrated simulator'],
    },indent=2))

if __name__=='__main__':main()
