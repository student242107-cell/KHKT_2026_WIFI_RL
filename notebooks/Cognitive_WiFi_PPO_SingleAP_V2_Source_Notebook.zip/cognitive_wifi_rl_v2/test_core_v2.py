"""Pure-NumPy tests; do NOT require Stable-Baselines3 or a router."""
import unittest
import numpy as np
from wifi_rl_core_v2 import (
 SingleAPRadioCore,covered_20mhz,encode_shadow_observation,
 validate_telemetry_snapshot,safe_legacy7_from3,OBS8_NAMES)

class TestCognitiveWiFiCore(unittest.TestCase):
    def test_channel_bonding(self):
        self.assertEqual(covered_20mhz(0,2),covered_20mhz(1,2))
        self.assertEqual(covered_20mhz(1,2),covered_20mhz(2,2))
        self.assertEqual(covered_20mhz(0,1),(36,40))
        self.assertEqual(covered_20mhz(1,1),(36,40))
        self.assertEqual(covered_20mhz(2,1),(44,48))
        self.assertEqual(covered_20mhz(0,0),(36,))
        self.assertEqual(covered_20mhz(2,0),(44,))

    def test_seed_reproducible(self):
        a=SingleAPRadioCore(); b=SingleAPRadioCore()
        a.reset(seed=123); b.reset(seed=123)
        self.assertTrue(np.array_equal(a.observe(),b.observe()))
        for _ in range(24):
            z1,r1,_=a.transition([0,2,3])
            z2,r2,_=b.transition([0,2,3])
            self.assertEqual(z1,z2)
            self.assertEqual(r1,r2)

    def test_state_is_action_dependent(self):
        x=SingleAPRadioCore();y=SingleAPRadioCore()
        x.reset(43); y.reset(43)
        a,r,_=x.transition([0,0,0])
        b,s,_=y.transition([2,2,6])
        # UL station RSSI must NOT be inferred directly from AP TX power.
        self.assertNotEqual(float(a['capacity_mbps']),float(b['capacity_mbps']))
        self.assertNotEqual(r,s)
        self.assertFalse(np.array_equal(x.observe(),y.observe()))

    def test_queue_and_goodput_bounded(self):
        env=SingleAPRadioCore();env.reset(77)
        for i in range(100):
            m,r,_=env.transition([0,0,0])
            self.assertGreaterEqual(m['queue_mbit'],0)
            self.assertLessEqual(m['queue_mbit'],env.params.queue_limit_mbit)
            self.assertGreaterEqual(m['throughput_mbps'],0)
            self.assertLessEqual(m['throughput_mbps'],m['capacity_mbps']+1e-5)
            self.assertTrue(0<=m['loss_rate']<=1)
            self.assertTrue(0<=m['uqs_proxy']<=1)
            self.assertTrue(np.isfinite(r))
            self.assertTrue(np.all(np.isfinite(env.observe())))
            self.assertTrue(np.all((env.observe()>=0)&(env.observe()<=1)))

    def test_bridge(self):
        np.testing.assert_array_equal(safe_legacy7_from3([1,2,5]),[1,2,5,7,1,0,0])
        with self.assertRaises(ValueError):
            safe_legacy7_from3([99,2,1])

    def test_shadow_schema(self):
        snap={k:v for k,v in zip(OBS8_NAMES,[-55,-94,19,.11,.16,.38,.4,0])}
        outcome=validate_telemetry_snapshot(snap)
        self.assertTrue(outcome['shadow_only'])
        self.assertGreater(len(outcome['alerts']),0)
        a=encode_shadow_observation(outcome['observation8'],[0,2,3],2)
        self.assertEqual(a.shape,(12,))
        self.assertTrue(np.all((a>=0)&(a<=1)))
        with self.assertRaises(ValueError):
            validate_telemetry_snapshot(dict(snap,noise_floor=None))

if __name__=='__main__':unittest.main()
