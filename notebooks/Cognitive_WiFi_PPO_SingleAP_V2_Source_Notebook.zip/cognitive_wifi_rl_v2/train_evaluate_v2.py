"""Offline training / validation / benchmarking. No SSH or real router commands.

Run after installing requirements_v2.txt. Synthetic metrics are NOT measured KPIs.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
from statistics import mean
import sys
import numpy as np
from wifi_rl_core_v2 import (CognitiveSingleAPEnv,RadioParams,OBS12_NAMES,
                            ACTION3_NAMES,ACTION3_NVECS,fixed_baseline,heuristic_baseline)


def _require_sb3():
    try:
        from stable_baselines3 import PPO
        from stable_baselines3.common.callbacks import EvalCallback
        from stable_baselines3.common.env_util import make_vec_env
        from stable_baselines3.common.monitor import Monitor
        from stable_baselines3.common.env_checker import check_env
        return PPO,EvalCallback,make_vec_env,Monitor,check_env
    except ImportError as e:
        raise RuntimeError('Install requirements_v2.txt first: pip install -r requirements_v2.txt') from e


def run_one_episode(policy, seed:int, mode='validation', episode_steps=120):
    """Return per-step metrics on paired deterministic synthetic seeds."""
    PPO,*_=_require_sb3()
    env=CognitiveSingleAPEnv(RadioParams(episode_steps=episode_steps,validate_mode=mode))
    obs,_=env.reset(seed=seed)
    rows=[];finished=False
    while not finished:
        if isinstance(policy,str):
            raw=np.array([env.core.metrics[k] for k in (
                'avg_rssi','noise_floor','sta_count','retry_rate','p_c',
                'airtime_util','ofdma_ratio','is_break_time')],np.float32)
            if policy=='fixed': action=fixed_baseline(raw)
            elif policy=='heuristic': action=heuristic_baseline(raw)
            else: raise ValueError(policy)
        else:
            action,_=policy.predict(obs,deterministic=True)
        obs,reward,terminated,truncated,info=env.step(action)
        rows.append({k:float(info[k]) for k in
            ('reward','sla_pass','changed_radio','changed_tx','throughput_mbps',
             'latency_p99_ms','loss_rate','uqs_proxy','offered_mbps',
             'queue_mbit','capacity_mbps')})
        finished=terminated or truncated
    env.close()
    return rows


def evaluate_benchmark(policies:dict, *, seeds, mode='validation',
                       episode_steps=120, export=None):
    """Held-out paired-seed scenarios, includes simple per-episode summary CIs.
    95% CIs are percentile bootstrap across episodes, not across correlated steps.
    """
    output=[]
    for name,policy in policies.items():
        for seed in seeds:
            rr=run_one_episode(policy,seed,mode,episode_steps)
            d={'policy':name,'seed':int(seed),'mode':mode}
            for k in rr[0]:
                d[k]=float(np.mean([row[k] for row in rr]))
            d['sla_all_steps_pass']=float(all(row['sla_pass']>0.5 for row in rr))
            output.append(d)
    if export is not None:
        path=Path(export);path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('w',newline='',encoding='utf-8') as fh:
            writer=csv.DictWriter(fh,fieldnames=list(output[0].keys()))
            writer.writeheader(); writer.writerows(output)
    return output


def bootstrap_ci(rows, key, seed=2027, n_boot=1000):
    vals=np.array([r[key] for r in rows],dtype=float)
    rng=np.random.default_rng(seed)
    picks=rng.choice(vals,size=(n_boot,len(vals)),replace=True)
    return tuple(float(v) for v in np.quantile(picks.mean(axis=1),[.025,.975]))


def summarize(rows):
    summary={}
    for name in sorted({r['policy'] for r in rows}):
        subset=[x for x in rows if x['policy']==name]
        metrics={}
        for k in ('reward','throughput_mbps','latency_p99_ms','loss_rate','uqs_proxy',
                  'sla_pass','changed_radio','sla_all_steps_pass'):
            metrics[k]={'mean':float(np.mean([r[k] for r in subset])),
                        'ci95':bootstrap_ci(subset,k)}
        summary[name]=metrics
    return summary


def train_one(seed:int, timesteps:int, directory:Path, n_envs:int=4):
    PPO,EvalCallback,make_vec_env,Monitor,check_env=_require_sb3()
    out=directory/f'seed_{seed}'
    out.mkdir(parents=True,exist_ok=True)
    check_env(CognitiveSingleAPEnv(RadioParams()),warn=True)
    def factory():
        return CognitiveSingleAPEnv(RadioParams(validate_mode='train'))
    env=make_vec_env(factory,n_envs=n_envs,seed=seed)
    eval_env=Monitor(CognitiveSingleAPEnv(RadioParams(validate_mode='validation')))
    model=PPO('MlpPolicy',env,learning_rate=3e-4,n_steps=512,
              batch_size=256,n_epochs=10,gamma=.98,gae_lambda=.95,
              clip_range=.2,ent_coef=.01,policy_kwargs={'net_arch':{'pi':[128,128],'vf':[128,128]}},
              verbose=1,seed=seed,device='cpu',tensorboard_log=str(out/'tb'))
    callback=EvalCallback(eval_env,best_model_save_path=str(out/'selection'),
                          log_path=str(out/'validation'),
                          eval_freq=max(1,20000//n_envs),
                          n_eval_episodes=15,deterministic=True,verbose=1)
    model.learn(total_timesteps=timesteps,callback=callback,progress_bar=False)
    model.save(str(out/'last_model'))
    ckpt=out/'selection'/'best_model.zip'
    if not ckpt.is_file():
        raise RuntimeError('Expected best checkpoint was not saved; increase training timesteps')
    return ckpt


def assert_checkpoint_schema(model):
    """Prevents loading old 8D/7D model in a new 12D/3D pipeline."""
    if tuple(model.observation_space.shape)!=(12,):
        raise ValueError(f'Checkpoint obs shape {model.observation_space.shape} != 12')
    if tuple(map(int,model.action_space.nvec))!=(3,3,7):
        raise ValueError(f'Checkpoint action nvec {model.action_space.nvec} != [3,3,7]')


def manifest():
    return {
      'pipeline':'CognitiveWiFi-SingleAP-Synthetic-v2',
      'model_observation_schema':list(OBS12_NAMES),
      'model_observation_normalized_0_to_1':True,
      'action_schema':list(ACTION3_NAMES),
      'action_nvec':list(map(int,ACTION3_NVECS)),
      'supported_hardware_operations_reported_by_author':['channel','bandwidth','txpower'],
      'unverified_hardware_operations':['mcs_ceiling','beacon','obss_pd','beamform'],
      'deployment_status':'SHADOW_ONLY_UNCALIBRATED',
      'required_before_hil':['readback actual applied configuration','calibrate RF/queue model',
                            'collect genuine flow QoE traces','offline replay and shadow validation',
                            'verify channel legality and bounded actions','rollback/guardrails'],
      'legacy_8d_7d_compatible':False,
      'multi_ap_joint_training':False,
      'synthetic_p99_is_not_measured_p99':True,
    }


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--timesteps',type=int,default=360000)
    parser.add_argument('--seeds',type=int,nargs='+',default=[11,22,33])
    parser.add_argument('--out',type=Path,default=Path('runs/cognitive_wifi_v2'))
    parser.add_argument('--test-only',type=Path,default=None)
    args=parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    PPO,*_=_require_sb3()
    policies={}
    if args.test_only is None:
        for seed in args.seeds:
            p=train_one(seed,args.timesteps,args.out)
            m=PPO.load(str(p),device='cpu');assert_checkpoint_schema(m)
            policies[f'ppo_seed_{seed}']=m
    else:
        m=PPO.load(str(args.test_only),device='cpu');assert_checkpoint_schema(m)
        policies['ppo']=m
    policies={'fixed': 'fixed','heuristic':'heuristic',**policies}
    # Choose policy using ONLY validation. Test is consulted exactly once afterwards.
    val_seeds=range(20000,20040)
    val=evaluate_benchmark(policies,seeds=val_seeds,mode='validation',
                           export=args.out/'validation_episodes.csv')
    val_sum=summarize(val)
    ppo_names=[n for n in policies if n.startswith('ppo')]
    selected=max(ppo_names,key=lambda n:val_sum[n]['reward']['mean'])
    test_policies={'fixed':'fixed','heuristic':'heuristic','selected_ppo':policies[selected]}
    test=evaluate_benchmark(test_policies,seeds=range(90000,90100),mode='ood',
                            export=args.out/'heldout_ood_episodes.csv')
    report={'model_status':'NOT_VALIDATED_FOR_REAL_ROUTER','selected_using_validation':selected,
            'validation':val_sum,'heldout_ood_test':summarize(test),
            'caveat':'Synthetic uncalibrated test; not evidence of operational Wi-Fi gains.'}
    (args.out/'report_v2.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
    (args.out/'model_manifest_v2.json').write_text(json.dumps(manifest(),indent=2,ensure_ascii=False),encoding='utf8')
    print(json.dumps(report,indent=2,ensure_ascii=False))
    if args.test_only is None:
        # Never overwrite/rename original checkpoint. Selection is by validation only.
        import shutil
        src=args.out/f"seed_{selected.split('_')[-1]}"/'selection'/'best_model.zip'
        shutil.copy2(src,args.out/'best_model_v2_UNCALIBRATED.zip')
    print('SHADOW ONLY: do not replace live saved_models/best_model.zip')

if __name__=='__main__':
    main()
