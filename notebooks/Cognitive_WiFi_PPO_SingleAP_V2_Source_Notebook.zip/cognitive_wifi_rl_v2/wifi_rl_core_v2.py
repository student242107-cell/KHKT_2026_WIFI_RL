"""Cognitive Wi-Fi v2: SINGLE-AP, OFFLINE, SYNTHETIC controller research environment.

IMPORTANT: This is a deliberately simplified, uncalibrated *research simulator*,
NOT an IEEE 802.11 PHY/MAC emulator and NOT suitable to justify autonomous
configuration changes on production routers.

The safe deployable action subset is [primary_channel, channel_width, tx_power].
Four other legacy actions are explicitly NOT enabled until hardware validation.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import math
import numpy as np

try:
    import gymnasium as gym
    from gymnasium import spaces
except ImportError:
    gym = None
    spaces = None

OBS8_NAMES = (
    'avg_rssi', 'noise_floor', 'sta_count', 'retry_rate', 'p_c',
    'airtime_util', 'ofdma_ratio', 'is_break_time',
)
OBS12_NAMES = OBS8_NAMES + ('current_channel_idx', 'current_bw_idx',
                           'current_tx_idx', 'dwell_time_fraction')
ACTION3_NAMES = ('channel_idx', 'bandwidth_idx', 'tx_power_idx')
ACTION3_NVECS = np.array([3, 3, 7], dtype=np.int64)
CHANNELS_5G = np.array([36, 40, 44], dtype=np.int64)
WIDTHS_MHZ = np.array([20, 40, 80], dtype=np.int64)
TX_POWERS_DBM = np.arange(14, 21, dtype=np.int64)
# Legacy action mapping for *display / shadow-mode* only.
# The four unsupported dimensions stay fixed and are NOT advertised as verified.
LEGACY_SAFE_UNVERIFIED_INDEX = np.array([7, 1, 0, 0], dtype=np.int64)  # mcs, beacon, obss_pd, bf
# Two spatial streams, approximately nominal HE 20 MHz GI 0.8us rates (Mbps);
# values are approximate anchors, NOT a calibrated link predictor.
HE20_TWO_NSS_Mbps = np.array([17.2,34.4,51.6,68.8,103.2,137.6,
                             154.9,172.1,206.5,229.4,258.1,286.8], dtype=float)
SINR_REQ_DB = np.array([1,3,5,7,10,13,16,19,22,25,28,31], dtype=float)


def covered_20mhz(channel_index: int, bandwidth_index: int) -> tuple[int, ...]:
    """For the chosen primary in the 36-48 block, return occupied 20MHz bins.

    CH36/40/44 as HE80 choices occupy exactly the same four bins.
    Returns channel IDs, not 'orthogonal channel numbers'.
    """
    ch = int(CHANNELS_5G[int(channel_index)])
    width = int(WIDTHS_MHZ[int(bandwidth_index)])
    if width == 20:
        return (ch,)
    if width == 40:
        return (36, 40) if ch in (36, 40) else (44, 48)
    return (36, 40, 44, 48)


def _dbm_from_linear_mw(mw: float) -> float:
    return 10.0 * math.log10(max(1e-20, mw))


def _linear_mw(dbm: float) -> float:
    return 10.0 ** (dbm / 10.0)


@dataclass
class RadioParams:
    dt_s: float = 10.0
    episode_steps: int = 120
    queue_limit_mbit: float = 12.0
    mac_efficiency: float = 0.68
    radio_rate_scale: float = 1.0
    # These are sensitivity parameters, not measurement-calibrated constants.
    packet_loss_slope: float = 0.18
    swap_outage_s: float = 1.0
    burden_txpower: float = 0.015
    obs_noise_rssi_std: float = 0.7
    validate_mode: str = 'train'  # 'train', 'validation', 'ood'


class SingleAPRadioCore:
    """Action-dependent Markov-state simulator with exogenous, correlated loads.

    Only the local AP is simulated; external channel occupancy is generated as
    a stochastic process. No claim to multi-AP centralized optimization.
    """
    def __init__(self, params: RadioParams | None = None):
        self.params = params or RadioParams()
        self.rng = np.random.default_rng(0)
        self.t = 0
        self.config = np.array([0, 2, 3], dtype=np.int64)
        self.time_on_config = 100
        self.offer_mbps = 50.0
        self.client_count = 16
        self.rssi_base_dbm_at17 = -61.0
        self.noise_dbm = np.full(4, -95.0)
        self.channel_occupancy = np.full(4, .10)
        self.queue_mbit = 0.0
        self.break_time = 0
        self.metrics: dict[str, float] = {}
        self.regime = 0
        self.phase_length = 0

    def reset(self, seed: int, params: RadioParams | None = None) -> dict[str, float]:
        if params is not None:
            self.params = params
        self.rng = np.random.default_rng(int(seed))
        self.t = 0
        self.config = np.array([0, 2, 3], dtype=np.int64)
        self.time_on_config = 100
        self.queue_mbit = 0.0
        self.regime = int(self.rng.choice([0,1,2],p=[.5,.3,.2]))
        self.phase_length = int(self.rng.integers(8, 26))
        self.rssi_base_dbm_at17 = float(self.rng.uniform(-75,-49))
        self.client_count = int(self.rng.integers(6,45))
        self.offer_mbps = float(self.rng.uniform(20,100))
        self.noise_dbm = self.rng.uniform(-99, -89, size=4)
        self.channel_occupancy = self.rng.uniform(.04, .23, size=4)
        self.break_time = 0
        self.metrics = self._calculate_observables_initial()
        return self.metrics.copy()

    def _calculate_observables_initial(self) -> dict[str, float]:
        covered = covered_20mhz(int(self.config[0]),int(self.config[1]))
        ids=[(ch-36)//4 for ch in covered]
        noise=float(np.mean(self.noise_dbm[ids]))
        return dict(avg_rssi=float(self.rssi_base_dbm_at17),
                    noise_floor=noise, sta_count=float(self.client_count),
                    retry_rate=.08, p_c=.05,
                    airtime_util=float(np.mean(self.channel_occupancy[ids])),
                    ofdma_ratio=float(np.clip(.75-.003*self.client_count,0,1)),
                    is_break_time=float(self.break_time),
                    throughput_mbps=0.0, latency_p99_ms=3.0, loss_rate=0.0,
                    uqs_proxy=1.0, offered_mbps=float(self.offer_mbps),
                    queue_mbit=0.0, capacity_mbps=0.0)

    def observe(self) -> np.ndarray:
        """Return normalized 12D observation, with stable train/inference scaling."""
        m=self.metrics
        base=np.array([m[k] for k in OBS8_NAMES],dtype=np.float32)
        low=np.array([-90,-105,0,0,0,0,0,0],np.float32)
        high=np.array([-30,-50,300,1,1,1,1,1],np.float32)
        x=(np.clip(base,low,high)-low)/(high-low)
        extras=[float(self.config[0]/2),float(self.config[1]/2),
                float(self.config[2]/6),float(min(self.time_on_config/12,1.0))]
        return np.clip(np.array([*x,*extras],dtype=np.float32),0,1)

    def _advance_exogenous(self) -> None:
        r=self.rng
        self.t += 1
        self.phase_length -= 1
        if self.phase_length <= 0:
            # stochastic regime switching, not a fixed four-phase curriculum
            p=[.51,.27,.22] if self.params.validate_mode=='train' else [0.34,.34,.32]
            if self.params.validate_mode=='ood': p=[.17,.33,.50]
            self.regime=int(r.choice([0,1,2],p=p))
            self.phase_length=int(r.integers(5,25))
        target_sta=[18,55,135][self.regime]
        target_load=[40,130,300][self.regime]
        if self.params.validate_mode=='ood':
            target_sta= int(target_sta*1.3)
            target_load= int(target_load*1.7)
        self.client_count=int(np.clip(.82*self.client_count+.18*target_sta+r.normal(0,5),1,300))
        self.offer_mbps=float(np.clip(.78*self.offer_mbps+.22*target_load+r.normal(0,22),2,700))
        # correlated per-channel interference time series; independent shocks
        target_busy=np.array([.10,.14,.12,.08])
        if self.regime == 1:
            target_busy[int(r.integers(0,3))] = .70
        elif self.regime == 2:
            target_busy[r.choice(4,size=2,replace=False)] = .76
        self.channel_occupancy=np.clip(.78*self.channel_occupancy +.22*target_busy+
                                       r.normal(0,.035,size=4), 0,.98)
        target_noise=-97.0+26.0*self.channel_occupancy
        self.noise_dbm=np.clip(.75*self.noise_dbm+.25*target_noise+
                               r.normal(0,1.2,size=4),-105,-55)
        self.rssi_base_dbm_at17=float(np.clip(self.rssi_base_dbm_at17 +
                                             r.normal(0,.45), -87,-39))
        self.break_time=int(((self.t//36)%3)==2)

    def transition(self, action: np.ndarray | list[int]) -> tuple[dict[str,float],float,dict[str,float]]:
        a=np.asarray(action,dtype=np.int64).reshape(-1)
        if a.shape != (3,) or np.any(a<0) or np.any(a>=ACTION3_NVECS):
            raise ValueError('Action must be 3 indexes within MultiDiscrete([3,3,7])')
        old=self.config.copy()
        changed=(a!=old)
        channel_change=bool(changed[0]);width_change=bool(changed[1]);tx_change=bool(changed[2])
        # A channel/width reconfiguration consumes some service time; this is a
        # tunable assumption, NOT a device-verified outage time.
        outage=self.params.swap_outage_s if (channel_change or width_change) else 0.0
        self.config=a.copy()
        self.time_on_config = 0 if np.any(changed) else self.time_on_config+1
        self._advance_exogenous()
        bin_channels=covered_20mhz(int(a[0]),int(a[1]))
        ids=np.array([(c-36)//4 for c in bin_channels],dtype=int)
        width=int(WIDTHS_MHZ[int(a[1])]);tx_power=int(TX_POWERS_DBM[int(a[2])])
        # power summation across 20MHz bins; high bandwidth aggregates noise
        # station dump signal is received UL RSSI; AP Tx power chiefly affects DL
        # signal, not measured station uplink RSSI. Keep these distinct.
        uplink_rssi_dbm=float(np.clip(self.rssi_base_dbm_at17,-90,-30))
        downlink_rssi_dbm=float(np.clip(self.rssi_base_dbm_at17+tx_power-17.0,-90,-30))
        noise_mw=float(sum(_linear_mw(float(n)) for n in self.noise_dbm[ids]))
        noise_floor=_dbm_from_linear_mw(noise_mw)
        sinr=downlink_rssi_dbm-noise_floor
        mcs_idx=int(np.clip(np.searchsorted(SINR_REQ_DB,sinr,side='right')-1,0,11))
        phy_rate=float(HE20_TWO_NSS_Mbps[mcs_idx]*(width/20.0)*self.params.radio_rate_scale)
        busy=float(np.mean(self.channel_occupancy[ids]))
        competing=busy
        # collision proxy grows smoothly with associated stations and occupancy
        collision=float(np.clip(.015 + .28*(self.client_count/(self.client_count+55.0))+
                                .20*competing, 0, .75))
        phy_err=float(np.clip((SINR_REQ_DB[mcs_idx]+2-sinr)/20.0,0,.15))
        radio_service=max(1.,phy_rate*self.params.mac_efficiency*(1-competing)*
                          (1-collision)*(1-phy_err))
        radio_service*=max(0.,1-outage/self.params.dt_s)
        # Finite queue with arrivals and service in Mbit per decision interval
        arrivals=self.offer_mbps*self.params.dt_s
        available=self.queue_mbit+arrivals
        serviced=min(available,radio_service*self.params.dt_s)
        backlogged=max(0.,available-serviced)
        overflow=max(0.,backlogged-self.params.queue_limit_mbit)
        self.queue_mbit=float(backlogged-overflow)
        # End-to-end delivered = service less PHY residual loss; never exceeds offered+backlog
        delivered=max(0.,serviced*(1-phy_err))
        achieved_goodput=float(delivered/self.params.dt_s)
        step_drop=float(overflow + serviced*phy_err)
        drop_fraction=float(np.clip(step_drop/max(1e-9,arrivals),0,1))
        utilization=float(np.clip(self.offer_mbps/max(radio_service,1e-6),0,3))
        # Synthetic per-packet delays (not a driver-measured p99)
        queue_ms=(self.queue_mbit/max(1.,radio_service))*1000.0
        base_delay=2.0 + queue_ms + (outage*1000)/max(1.,self.params.dt_s)
        # fixed sample count ensures comparisons have consistent sampling effort
        samples=np.clip(base_delay+self.rng.lognormal(mean=.35,sigma=.38,size=64),0,5000)
        p99=float(np.percentile(samples,99))
        uqs=float(np.clip(min(self.offer_mbps,achieved_goodput)/max(1.,self.offer_mbps),0,1))
        rate_retry=float(np.clip(collision+phy_err+.005*self.queue_mbit,0,1))
        ofdma=float(np.clip(.70-.20*utilization-.001*self.client_count+
                             self.rng.normal(0,.03),0,1))
        # noisy survey measurement proxies for PHY/MAC; label as synthetic
        m={
          'avg_rssi':float(np.clip(uplink_rssi_dbm+self.rng.normal(0,self.params.obs_noise_rssi_std),-90,-30)),
          'noise_floor':float(np.clip(noise_floor+self.rng.normal(0,.7),-105,-50)),
          'sta_count':float(self.client_count),
          'retry_rate':rate_retry,
          'p_c':collision,
          'airtime_util':float(np.clip(max(competing,utilization*.70),0,1)),
          'ofdma_ratio':ofdma,'is_break_time':float(self.break_time),
          'throughput_mbps':achieved_goodput,
          'latency_p99_ms':p99,'loss_rate':drop_fraction,'uqs_proxy':uqs,
          'offered_mbps':float(self.offer_mbps),'queue_mbit':float(self.queue_mbit),
          'capacity_mbps':float(radio_service),
          'switch_outage_s':float(outage),
        }
        self.metrics=m
        # Reward is a prospective candidate, not the research utility U(X).
        reward=(1.3*uqs + 0.5*min(achieved_goodput/200.0,1.5)
                -1.7*drop_fraction -0.8*min(p99/100.0,5.0)
                -.25*channel_change -.10*width_change -.025*tx_change
                -self.params.burden_txpower*(tx_power-14)/6)
        # SLA uses *sampled synthetic* latency, not real network P99.
        info={
           'reward':float(reward), 'sla_pass':float(p99<=15 and drop_fraction<.01),
           'changed_radio':float(channel_change or width_change),
           'changed_tx':float(tx_change),
        }
        return m.copy(),float(reward),info


class CognitiveSingleAPEnv(gym.Env if gym is not None else object):
    """Gymnasium adapter, OBS 12D / ACTION 3D. NOT compatible with old 8D/7D weights."""
    metadata = {'render_modes': []}
    def __init__(self, params: RadioParams | None = None):
        if gym is None:
            raise ImportError('pip install gymnasium stable-baselines3')
        super().__init__()
        self.params=params or RadioParams()
        self.core=SingleAPRadioCore(self.params)
        self.observation_space=spaces.Box(low=0.0,high=1.0,shape=(12,),dtype=np.float32)
        self.action_space=spaces.MultiDiscrete(ACTION3_NVECS)
        self.elapsed=0

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        if seed is None:
            seed=int(self.np_random.integers(0,2**31-1))
        self.core.reset(seed=int(seed))
        self.elapsed=0
        return self.core.observe(), {'model_type':'synthetic_uncalibrated_v2'}

    def step(self, action):
        m,r,info=self.core.transition(action)
        self.elapsed+=1
        terminated=False
        truncated=bool(self.elapsed>=self.params.episode_steps)
        return self.core.observe(), float(r),terminated,truncated,dict(info,**m)

    def render(self):
        return None


def encode_shadow_observation(raw_obs8: np.ndarray, current_action3: np.ndarray,
                              dwell_cycles: int) -> np.ndarray:
    """Reproduce the exact 12D train-time scaling at inference."""
    raw=np.asarray(raw_obs8,dtype=np.float32).reshape(-1)
    a=np.asarray(current_action3,dtype=np.int64).reshape(-1)
    if raw.shape!=(8,) or a.shape!=(3,) or np.any(a<0) or np.any(a>=ACTION3_NVECS):
        raise ValueError('Expected 8 sensor values and applied 3D configuration')
    low=np.array([-90,-105,0,0,0,0,0,0],np.float32)
    high=np.array([-30,-50,300,1,1,1,1,1],np.float32)
    if np.any(~np.isfinite(raw)) or np.any(raw<low) or np.any(raw>high):
        raise ValueError('Invalid raw sensor values')
    out=np.concatenate([(raw-low)/(high-low),
        np.array([a[0]/2,a[1]/2,a[2]/6,min(max(0,dwell_cycles)/12,1.0)],np.float32)])
    return out.astype(np.float32)


def heuristic_baseline(obs: np.ndarray) -> np.ndarray:
    """Conservative comparator with ONLY current-channel telemetry (no oracle info)."""
    rssi, noise, sta, retry, pc, busy, ofdma, brk = np.asarray(obs)[:8]
    # If alternative-channel occupancy is unavailable, do not assert CH40/44 cleaner.
    ch=0
    bw=0 if (busy>.70 or pc>.35) else 2 if busy<.30 else 1
    tx=5 if rssi < -68 else 3 if rssi < -57 else 1
    return np.array([ch,bw,tx],dtype=np.int64)


def fixed_baseline(obs: np.ndarray) -> np.ndarray:
    return np.array([0,2,3],dtype=np.int64)


def safe_legacy7_from3(action: np.ndarray | list[int]) -> np.ndarray:
    """Bridge for reading only; NOT authorization to send unsupported commands."""
    x=np.asarray(action,dtype=np.int64).reshape(-1)
    if x.shape!=(3,) or np.any(x<0) or np.any(x>=ACTION3_NVECS):
        raise ValueError('Invalid 3D action')
    return np.array([x[0],x[1],x[2],*LEGACY_SAFE_UNVERIFIED_INDEX],dtype=np.int64)


def validate_telemetry_snapshot(snapshot: dict, *, stale_seconds: float | None=None) -> dict:
    """Reject missing data and highlight proxy flags instead of inventing values."""
    from collections.abc import Mapping
    if not isinstance(snapshot,Mapping):
        raise TypeError('Telemetry must be a mapping')
    m={}
    for k in OBS8_NAMES:
        if k not in snapshot or snapshot[k] is None:
            raise ValueError(f'Missing live field {k}; never impute fake PHY values')
        v=float(snapshot[k]);
        if not np.isfinite(v):
            raise ValueError(f'Invalid {k}={snapshot[k]}')
        m[k]=v
    arr=np.array([m[k] for k in OBS8_NAMES],np.float32)
    low=np.array([-90,-105,0,0,0,0,0,0],np.float32)
    high=np.array([-30,-50,300,1,1,1,1,1],np.float32)
    if np.any(arr<low) or np.any(arr>high):
        raise ValueError('Observation out of training bounds: do not silently clip')
    alerts=[]
    for k in ('noise_floor','ofdma_ratio'):
        if snapshot.get(f'{k}_measured') is not True:
            alerts.append(f'{k} provenance not independently confirmed')
    if stale_seconds is None:
        alerts.append('snapshot freshness unspecified')
    elif stale_seconds>10:
        alerts.append(f'snapshot is stale ({stale_seconds:.1f}s)')
    return {'observation8':arr,'alerts':alerts,'shadow_only':True}
